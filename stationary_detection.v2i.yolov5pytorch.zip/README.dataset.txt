# stationary_detection > 2025-04-28 6:40pm
https://universe.roboflow.com/stationarydetection-go0vx/stationary_detection-9ukdh

Provided by a Roboflow user
License: CC BY 4.0

